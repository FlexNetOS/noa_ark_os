use anyhow::{anyhow, Result};
use clap::Parser;
use std::{path::PathBuf, time::Duration};
use tokio::{process::Command, time::sleep};

#[derive(Parser, Debug)]
#[command(name="aos-watchdog", about="Health-check loop with auto-rollback")]
struct Cli {
  /// AgenticOS root
  #[arg(long, default_value="/opt/agenticos")]
  root: PathBuf,

  /// Health URL(s), comma-separated (e.g., http://127.0.0.1:8080/health,http://127.0.0.1:8083/health)
  #[arg(long)]
  health_urls: Option<String>,

  /// Health command relative to current/bin (used if no URLs)
  #[arg(long, default_value="agent --version")]
  health_cmd: String,

  /// Check interval seconds
  #[arg(long, default_value_t=15)]
  interval: u64,

  /// Consecutive failures before rollback
  #[arg(long, default_value_t=5)]
  retries: u32,

  /// After rollback, restart this systemd unit (optional)
  #[arg(long)]
  restart_unit: Option<String>,
}

async fn http_ok(url: &str) -> bool {
  match reqwest::Client::new().get(url).timeout(Duration::from_secs(3)).send().await {
    Ok(r) => r.status().is_success(),
    Err(_) => false,
  }
}

async fn cmd_ok(root: &PathBuf, cmd: &str) -> bool {
  // resolve current/bin
  let mut parts = cmd.split_whitespace();
  let bin = parts.next().unwrap_or("agent");
  let args: Vec<_> = parts.collect();
  let exe = root.join("current/bin").join(bin);
  match Command::new(&exe).args(&args).kill_on_drop(true).status().await {
    Ok(s) => s.success(),
    Err(_) => false,
  }
}

async fn rollback(root: &PathBuf) -> Result<()> {
  // call aos-ctl rollback
  let status = Command::new("aos-ctl").arg("--root").arg(root).arg("rollback")
      .kill_on_drop(true).status().await?;
  if !status.success() { return Err(anyhow!("rollback failed")); }
  Ok(())
}

#[tokio::main]
async fn main() -> Result<()> {
  let cli = Cli::parse();
  let urls: Vec<String> = cli.health_urls
      .as_deref().unwrap_or("")
      .split(',').filter(|s| !s.trim().is_empty())
      .map(|s| s.trim().to_string()).collect();

  let mut failures: u32 = 0;
  loop {
    let ok = if !urls.is_empty() {
      // all must pass
      let mut pass = true;
      for u in &urls { if !http_ok(u).await { pass = false; break; } }
      pass
    } else {
      cmd_ok(&cli.root, &cli.health_cmd).await
    };

    if ok { failures = 0; }
    else {
      failures += 1;
      eprintln!("[watchdog] health failed ({}/{})", failures, cli.retries);
      if failures >= cli.retries {
        eprintln!("[watchdog] rolling back…");
        if let Err(e) = rollback(&cli.root).await {
          eprintln!("[watchdog] rollback error: {e}");
        } else if let Some(unit) = &cli.restart_unit {
          let _ = Command::new("systemctl").arg("restart").arg(unit).status().await;
        }
        failures = 0; // don’t loop-rollback
      }
    }
    sleep(Duration::from_secs(cli.interval)).await;
  }
}
