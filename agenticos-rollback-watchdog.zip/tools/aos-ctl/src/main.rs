use anyhow::{anyhow, Result};
use clap::{Parser, Subcommand};
use std::{fs, path::{Path, PathBuf}};

#[derive(Parser)]
#[command(name="aos-ctl", about="AgenticOS slot control")]
struct Cli {
  #[arg(long, default_value="/opt/agenticos")]
  root: PathBuf,
  #[command(subcommand)]
  cmd: Cmd
}
#[derive(Subcommand)]
enum Cmd {
  /// Show current/previous and available slots
  Status,
  /// List all slots
  List,
  /// Switch to a specific slot version (e.g., 2025.09.28)
  Switch { #[arg(long)] version: String },
  /// Roll back to the previous slot (if set)
  Rollback,
}

fn readlink(p: &Path) -> Option<PathBuf> { fs::read_link(p).ok() }

fn ensure_slot(root: &Path, version: &str) -> Result<PathBuf> {
  let slot = root.join("slots").join(version);
  if slot.is_dir() { Ok(slot) } else { Err(anyhow!("slot not found: {}", slot.display())) }
}

fn main() -> Result<()> {
  let cli = Cli::parse();
  match cli.cmd {
    Cmd::Status => {
      println!("root: {}", cli.root.display());
      println!("current -> {:?}", readlink(&cli.root.join("current")));
      println!("previous-> {:?}", readlink(&cli.root.join("previous")));
      println!("slots:");
      for e in fs::read_dir(cli.root.join("slots")).unwrap_or_default() {
        if let Ok(e) = e { if e.file_type()?.is_dir() { println!("  {}", e.file_name().to_string_lossy()); } }
      }
    }
    Cmd::List => {
      for e in fs::read_dir(cli.root.join("slots")).unwrap_or_default() {
        if let Ok(e) = e { if e.file_type()?.is_dir() { println!("{}", e.file_name().to_string_lossy()); } }
      }
    }
    Cmd::Switch { version } => {
      let slot = ensure_slot(&cli.root, &version)?;
      let tmp = cli.root.join(format!("current.{}", version));
      let cur = cli.root.join("current");
      let prev = cli.root.join("previous");

      // set previous -> old current
      if let Some(old) = readlink(&cur) {
        let tmp_prev = cli.root.join(format!("previous.{}", version));
        let _ = fs::remove_file(&tmp_prev);
        std::os::unix::fs::symlink(&old, &tmp_prev)?;
        fs::rename(&tmp_prev, &prev)?;
      }

      let _ = fs::remove_file(&tmp);
      std::os::unix::fs::symlink(&slot, &tmp)?;
      fs::rename(&tmp, &cur)?;
      println!("switched to {}", version);
    }
    Cmd::Rollback => {
      let prev = readlink(&cli.root.join("previous")).ok_or_else(|| anyhow!("no previous set"))?;
      let version = prev.file_name().and_then(|s| s.to_str()).unwrap_or("<unknown>").to_string();
      let tmp = cli.root.join(format!("current.rollback.{}", version));
      let cur = cli.root.join("current");
      let _ = fs::remove_file(&tmp);
      std::os::unix::fs::symlink(&prev, &tmp)?;
      fs::rename(&tmp, &cur)?;
      println!("rolled back to {}", version);
    }
  }
  Ok(())
}
