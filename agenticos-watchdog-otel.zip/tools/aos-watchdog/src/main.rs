use anyhow::{anyhow, Result};
use clap::Parser;
use std::{path::PathBuf, time::Duration};
use tokio::{process::Command, time::sleep};
use tracing::{error, info, warn};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

#[derive(Parser, Debug)]
#[command(name="aos-watchdog", about="Health-check loop with auto-rollback (+ OTLP traces)")]
struct Cli {
  /// AgenticOS root
  #[arg(long, default_value="/opt/agenticos")]
  root: PathBuf,

  /// Health URL(s), comma-separated (e.g., http://127.0.0.1:8080/health,http://127.0.0.1:8083/health)
  #[arg(long)]
  health_urls: Option<String>,

  /// Health command relative to current/bin (used if no URLs)
  #[arg(long, default_value="agent --version")]
  health_cmd: String,

  /// Check interval seconds
  #[arg(long, default_value_t=15)]
  interval: u64,

  /// Consecutive failures before rollback
  #[arg(long, default_value_t=5)]
  retries: u32,

  /// After rollback, restart this systemd unit (optional)
  #[arg(long)]
  restart_unit: Option<String>,

  /// Force-enable OTLP even if env is missing (requires endpoint env to be meaningful)
  #[arg(long)]
  otlp: bool,
}

async fn init_tracing(otlp_flag: bool) -> Result<()> {
  let endpoint = std::env::var("OTEL_EXPORTER_OTLP_ENDPOINT").ok();
  let service_name = std::env::var("OTEL_SERVICE_NAME").unwrap_or_else(|_| "aos-watchdog".to_string());

  let env_layer = tracing_subscriber::EnvFilter::try_from_default_env()
      .unwrap_or_else(|_| "info".into());

  // No OTLP endpoint and not forced -> plain stdout logs
  if endpoint.is_none() && !otlp_flag {
    tracing_subscriber::registry()
      .with(env_layer)
      .with(tracing_subscriber::fmt::layer().with_target(false))
      .init();
    return Ok(());
  }

  // Setup OTLP tracing exporter
  let headers = std::env::var("OTEL_EXPORTER_OTLP_HEADERS").ok();
  let mut exporter = opentelemetry_otlp::new_exporter().http();
  if let Some(ep) = endpoint.clone() { exporter = exporter.with_endpoint(ep); }
  if let Some(h) = headers {
    let map: Vec<(String,String)> = h.split(',').filter_map(|kv| kv.split_once('=')).map(|(k,v)| (k.trim().to_string(), v.trim().to_string())).collect();
    exporter = exporter.with_headers(map.into_iter().collect());
  }

  let res = opentelemetry_sdk::Resource::new(vec![
    opentelemetry::KeyValue::new("service.name", service_name),
    opentelemetry::KeyValue::new("service.namespace", "agenticos"),
    opentelemetry::KeyValue::new("service.version", env!("CARGO_PKG_VERSION")),
    opentelemetry::KeyValue::new("telemetry.sdk.language", "rust"),
  ]);

  let tracer = opentelemetry_otlp::new_pipeline()
    .tracing()
    .with_exporter(exporter)
    .with_trace_config(
      opentelemetry_sdk::trace::Config::default()
        .with_resource(res)
        .with_sampler(opentelemetry_sdk::trace::Sampler::ParentBased(Box::new(opentelemetry_sdk::trace::Sampler::AlwaysOn)))
    )
    .install_batch(opentelemetry_sdk::runtime::Tokio)?;

  let otel_layer = tracing_opentelemetry::layer().with_tracer(tracer);

  tracing_subscriber::registry()
    .with(env_layer)
    .with(tracing_subscriber::fmt::layer().with_target(false))
    .with(otel_layer)
    .init();

  Ok(())
}

async fn http_ok(url: &str) -> bool {
  match reqwest::Client::new().get(url).timeout(Duration::from_secs(3)).send().await {
    Ok(r) => r.status().is_success(),
    Err(_) => false,
  }
}

async fn cmd_ok(root: &PathBuf, cmd: &str) -> bool {
  // resolve current/bin
  let mut parts = cmd.split_whitespace();
  let bin = parts.next().unwrap_or("agent");
  let args: Vec<_> = parts.collect();
  let exe = root.join("current/bin").join(bin);
  match Command::new(&exe).args(&args).kill_on_drop(true).status().await {
    Ok(s) => s.success(),
    Err(_) => false,
  }
}

async fn rollback(root: &PathBuf) -> Result<()> {
  // call aos-ctl rollback
  let status = Command::new("aos-ctl").arg("--root").arg(root).arg("rollback")
      .kill_on_drop(true).status().await?;
  if !status.success() { return Err(anyhow!("rollback failed")); }
  Ok(())
}

#[tokio::main]
async fn main() -> Result<()> {
  let cli = Cli::parse();
  init_tracing(cli.otlp).await?;

  let urls: Vec<String> = cli.health_urls
      .as_deref().unwrap_or("")
      .split(',').filter(|s| !s.trim().is_empty())
      .map(|s| s.trim().to_string()).collect();

  let mut failures: u32 = 0;
  loop {
    let span = tracing::info_span!("watchdog.tick", urls = ?urls, interval = cli.interval, retries = cli.retries);
    let _g = span.enter();

    let ok = if !urls.is_empty() {
      let mut pass = true;
      for u in &urls {
        let s = tracing::info_span!("health.http", %u);
        let _e = s.enter();
        let res = http_ok(u).await;
        tracing::info!(ok = res, "checked");
        if !res { pass = false; }
      }
      pass
    } else {
      let s = tracing::info_span!("health.cmd", cmd = %cli.health_cmd);
      let _e = s.enter();
      let res = cmd_ok(&cli.root, &cli.health_cmd).await;
      tracing::info!(ok = res, "checked");
      res
    };

    if ok {
      failures = 0;
      info!("health ok");
    } else {
      failures += 1;
      warn!(failures, "health failed");
      if failures >= cli.retries {
        error!("threshold crossed → rollback");
        if let Err(e) = rollback(&cli.root).await {
          error!(err=?e, "rollback error");
        } else if let Some(unit) = &cli.restart_unit {
          let _ = Command::new("systemctl").arg("restart").arg(unit).status().await;
          info!(unit, "restarted service after rollback");
        }
        failures = 0; // reset
      }
    }

    sleep(Duration::from_secs(cli.interval)).await;
  }
}
