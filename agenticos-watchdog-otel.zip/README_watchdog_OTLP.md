# aos-watchdog (with OTLP traces)

This pack upgrades the watchdog to emit **OpenTelemetry traces** to any OTLP HTTP collector.
If `OTEL_EXPORTER_OTLP_ENDPOINT` is unset, it logs to stdout only.

## Build
```bash
cargo build --release -p aos-watchdog
```

## Systemd
- Install the binary to `/usr/local/bin/aos-watchdog`
- Install the unit file to `/etc/systemd/system/aos-watchdog.service`
- Create `/etc/agenticos/aos-watchdog.env` with your OTLP settings (sample included).

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now aos-watchdog
```

## Env (example)
```
OTEL_SERVICE_NAME=aos-watchdog
OTEL_EXPORTER_OTLP_ENDPOINT=http://127.0.0.1:4318
OTEL_RESOURCE_ATTRIBUTES=service.namespace=agenticos,service.version=0.2.0,env=prod
RUST_LOG=info
```

## What gets traced
- Each loop tick (`watchdog.tick`)
- Each health check (`health.http` or `health.cmd`) with success flag
- Rollback attempts and service restarts
