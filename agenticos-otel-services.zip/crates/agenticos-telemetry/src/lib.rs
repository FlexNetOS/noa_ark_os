use anyhow::Result;
use once_cell::sync::OnceCell;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

static INIT: OnceCell<()> = OnceCell::new();

pub fn init(service_name: &str) -> Result<()> {
    INIT.get_or_init(|| {
        opentelemetry::global::set_text_map_propagator(
            opentelemetry_sdk::propagation::TraceContextPropagator::new()
        );

        let env_filter = tracing_subscriber::EnvFilter::try_from_default_env()
            .unwrap_or_else(|_| "info".into());

        let endpoint = std::env::var("OTEL_EXPORTER_OTLP_ENDPOINT").ok();
        if endpoint.is_none() {
            tracing_subscriber::registry()
                .with(env_filter)
                .with(tracing_subscriber::fmt::layer().with_target(false))
                .init();
            return;
        }

        let headers = std::env::var("OTEL_EXPORTER_OTLP_HEADERS").ok();
        let mut exporter = opentelemetry_otlp::new_exporter().http();
        if let Some(ep) = endpoint { exporter = exporter.with_endpoint(ep); }
        if let Some(h) = headers {
            let map: std::collections::HashMap<String,String> = h
                .split(',')
                .filter_map(|kv| kv.split_once('='))
                .map(|(k,v)| (k.trim().to_string(), v.trim().to_string()))
                .collect();
            exporter = exporter.with_headers(map);
        }

        let res = opentelemetry_sdk::Resource::new(vec![
            opentelemetry::KeyValue::new("service.name", service_name.to_string()),
            opentelemetry::KeyValue::new("service.namespace", "agenticos"),
            opentelemetry::KeyValue::new("service.version", env!("CARGO_PKG_VERSION")),
        ]);

        let tracer = opentelemetry_otlp::new_pipeline()
            .tracing()
            .with_exporter(exporter)
            .with_trace_config(
                opentelemetry_sdk::trace::Config::default()
                    .with_resource(res)
                    .with_sampler(opentelemetry_sdk::trace::Sampler::ParentBased(
                        Box::new(opentelemetry_sdk::trace::Sampler::AlwaysOn)
                    ))
            )
            .install_batch(opentelemetry_sdk::runtime::Tokio)
            .expect("failed to init otlp");

        let otel_layer = tracing_opentelemetry::layer().with_tracer(tracer);

        tracing_subscriber::registry()
            .with(env_filter)
            .with(tracing_subscriber::fmt::layer().with_target(false))
            .with(otel_layer)
            .init();
    });
    Ok(())
}

pub fn shutdown() {
    opentelemetry::global::shutdown_tracer_provider();
}
