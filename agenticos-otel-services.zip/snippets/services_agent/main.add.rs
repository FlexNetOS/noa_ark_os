// services/agent/src/main.rs
use tracing::{info, instrument};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    agenticos_telemetry::init("agent")?;
    info!("agent boot");
    runner().await?;
    agenticos_telemetry::shutdown();
    Ok(())
}

#[instrument(skip_all)]
async fn runner() -> anyhow::Result<()> {
    // your agent loop here
    Ok(())
}
