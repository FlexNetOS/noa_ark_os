// services/retrieval/src/main.rs
use tracing::info;
use tracing_opentelemetry::OpenTelemetrySpanExt;
use opentelemetry_http::HeaderExtractor;
use tower_http::trace::{TraceLayer, DefaultOnResponse};
use http::{Request, HeaderMap};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    agenticos_telemetry::init("retrieval")?;

    let app = router()
        .layer(
            TraceLayer::new_for_http()
                .make_span_with(|req: &Request<_>| {
                    let headers: &HeaderMap = req.headers();
                    let parent_cx = opentelemetry::global::get_text_map_propagator(|prop| prop.extract(&HeaderExtractor(headers)));
                    let span = tracing::info_span!(
                        "http.server",
                        method = %req.method(),
                        uri = %req.uri(),
                        version = ?req.version()
                    );
                    span.set_parent(parent_cx);
                    span
                })
                .on_response(DefaultOnResponse::new().level(tracing::Level::INFO))
        );

    // serve...
    agenticos_telemetry::shutdown();
    Ok(())
}
