# OTLP Tracing for AgenticOS Services

This pack adds OpenTelemetry (OTLP/HTTP) tracing to:
- `services/api` (Axum)
- `services/retrieval` (Axum)
- `services/agent` (non-HTTP loop)

## 1) Add the shared telemetry crate
Copy `crates/agenticos-telemetry/` into your monorepo and include it in workspace.

## 2) Patch each service
- Append dependency snippets from `snippets/services_*/Cargo.append.toml`
- Add `main.add.rs` sections to call `agenticos_telemetry::init("<name>")` and wire the `TraceLayer` for HTTP services.

## 3) Systemd
- Put `packaging/systemd/otel.env` at `/etc/agenticos/otel.env`
- Add `EnvironmentFile=-/etc/agenticos/otel.env` to each unit
- `sudo systemctl daemon-reload && sudo systemctl restart api retrieval agent`

## 4) Collector
Set `OTEL_EXPORTER_OTLP_ENDPOINT` to your collector (e.g., `http://otelcol:4318`).
