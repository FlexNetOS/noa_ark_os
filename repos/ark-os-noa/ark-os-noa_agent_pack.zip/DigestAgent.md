# Digest Agent — Research/Digestion Pipeline (Board‑affiliated)

**Role:** The Board’s R&D arm for *“digest everything”* across code, data, CRMs, APIs, and models.

## Pipeline
1. **Discover:** enumerate sources; seed with repos/APIs/CRMs.
2. **Fetch:** clone/sync; handle auth & rate limits.
3. **Parse:** language‑aware parsing; extract metadata; **build SBOM**.
4. **Analyze:** embeddings, **knowledge graph** extraction, entity/linking.
5. **Summarize:** layered (file → module → repo → portfolio).
6. **Surface:** dashboards, markdown dossiers, cross‑refs.
7. **Secure:** classify secrets; quarantine policy.

## Tools
- Web research (current‑year), code/data analysis, file search.
- Security scanners, license checkers, and provenance trackers.

## Outputs
- `2025-08-22_digest_report.md`, structured JSONL indices, vector DB upserts.
