# Storage — Internal Data Plane for ark‑os‑noa

**Principle:** Keep storage *inside the trust boundary*; ship only signed artifacts outward.

## Components
- **Private OCI Registry:** images, capsules, build outputs.
- **MinIO (S3‑compatible):** large artifacts, datasets, zips, PDFs.
- **Postgres (+ pgvector):** metadata, traces, run logs, embeddings.
- **Supabase:** developer ergonomics & auth until fully internalized.

## Policies
- **Immutability:** content‑addressed storage; record SHA256 for every artifact.
- **Lineage:** every deliverable links back to inputs, tools, and models.
- **Retention:** short for volatile runs; long for specs and signed releases.
- **Access:** least privilege; temporary scoped tokens; audit every read/write.

## One‑liners
```bash
# Create local dirs mirroring services (for dev)
mkdir -p storage/{oci,minio,postgres,supabase,artifacts} && tree -L 2 storage || ls -R storage
```
