# BoardAgents — Executive Team of ark‑os‑noa

**Intent:** A small set of “executive” agents that each own a domain and can deploy **MicroAgentStacks**. The **Digest Agent** sits here as R&D/Research.

## Roster (suggested)
- **Strategy/CTO Agent:** Systems architecture, Capsule (Full‑Illusion), no‑DinD, platform cohesion.
- **COO Agent:** Runbooks, SLAs, scheduling, change management.
- **CFO/FinOps Agent:** Budgets, cost telemetry, model/tool spend optimization.
- **Legal/Compliance Agent:** Policy, licensing, data governance, export controls.
- **Security Agent:** Secrets, signing, SBOM attestation, supply‑chain risk.
- **Growth/Partnerships Agent:** Repos/APIs/CRMs ingestion roadmap, ecosystem strategy.
- **Digest Agent (R&D):** Deep research/digestion; see `DigestAgent.md`.

## Operating Rules
- Each Board Agent can **deploy multiple MicroAgentStacks** to complete tasks.
- Each stack has a **CommandChiefAgent** as its orchestrator.
- Board Agents request **ModelSelectorAgents** when specialization helps quality or cost.

## Capabilities
- Multi‑project scheduling; parallel stack spin‑up/spin‑down.
- Cross‑repo “digest-everything” initiatives with SBOM/security posture.
- Program governance: risks, mitigations, and decision logs.

## Tools & Signals
- **Research:** web browse (current‑year), code/data analysis, file search.
- **Change control:** PR gates, policy checks, security scans.
- **Telemetry:** traces, metrics, cost dashboards.
