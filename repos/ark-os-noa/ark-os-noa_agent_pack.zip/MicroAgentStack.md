# MicroAgentStack — Pattern & Lifecycle

**Definition:** A deployable cluster of cooperative agents to achieve a bounded objective. Each stack has a **CommandChiefAgent** as stack orchestrator.

## Composition
- **CommandChiefAgent (Stack Master):** orchestrates steps, resolves conflicts, enforces SLAs.
- **Operators:** code‑runner, data‑wrangler, doc‑generator, tester, packager.
- **Adapters:** repo/CRM/API connectors; artifact publishers.
- **Guards:** policy, security, and quality gates.

## Goals
- Deliver end‑to‑end outcomes (e.g., clone → digest → generate → test → package).
- Scale horizontally: spin up multiple stacks when parallelism helps.
- Tear down cleanly with full traces and artifact hashes.

## Lifecycle
1. **Bootstrap:** inputs → plan → environment prep (no‑DinD; use outer plane sidecars).
2. **Execute:** concurrent tasks with retries and backoffs.
3. **Validate:** acceptance tests, security checks, and human‑readable summaries.
4. **Package:** zip + PDF; publish locations; update indexes.
5. **Archive:** logs, SBOM, checksums, retention policy.

## One‑liners (examples)
```bash
# Create a new stack workspace
STACK=stack-$(date +%Y%m%d-%H%M%S); mkdir -p stacks/$STACK/{in,work,out,logs} && echo $STACK
```
