# ModelSelectorAgents — Specialist Model Selection for Board Agents

**Purpose:** Choose optimal models/tools per task under constraints (accuracy, latency, cost, privacy).

## Framework
- **Inputs:** Task description, size, privacy tier, latency budget, cost cap.
- **Decision Graph:** classify → estimate complexity → pick model/tool → assert guardrails.
- **Outputs:** Model/tool plan + rationale (recorded in trace).

## Default Policy (editable)
1. **Reasoning/Planning:** GPT‑5 Thinking.
2. **Bulk transforms / formatting:** fast, cost‑efficient model.
3. **Code & data:** use code/analysis tool; prefer sandboxed execution.
4. **Offline/local fallbacks:** call local runtime when privacy tier demands.

## Tools
- Model catalogs, local runner interfaces, and performance telemetry.
- Cost/latency forecaster with feedback loops.
